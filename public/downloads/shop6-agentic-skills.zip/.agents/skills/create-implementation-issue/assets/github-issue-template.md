# GitHub issue: <!-- concise outcome -->

<!-- Keep only relevant sections. Remove all comments before saving. Ensure the issue body is strictly bounded (<200 lines target, <=300 lines max) and scoped to a single architectural domain to prevent agent token explosion. -->

## Objective and context

<!-- State the user-visible or operational outcome and why current behavior is insufficient. -->

## Delivery identity

- Jira: `[<!-- JIRA-KEY -->](https://jtl.atlassian.net/browse/<!-- JIRA-KEY -->)` <!-- or `none` if skipped -->
- Branch: `<!-- For human/local branches: <type>/<JIRA-KEY>-<short-slug> (or <type>/<slug> if Jira skipped); For GitHub Copilot cloud agent tasks: leave on the assigned copilot/* branch (never instruct the agent to rename) -->`
- Commit format: `<!-- <type>(<optional-scope>): <JIRA-KEY> <summary> (or <type>(<optional-scope>): <summary> if Jira skipped); every authored commit includes the key when applicable -->`
- PR title: `<!-- [<JIRA-KEY>] Concise outcome (or Concise outcome if Jira skipped) -->`
- PR description: `<!-- Include the Jira key and canonical Jira URL when present. -->`

## Evidence

<!-- Cite current-repository paths with lines. Prefix sibling paths with the repository name. -->
<!-- Record branch and SHA for every repository used as evidence. Warn when a repository was not on or verified against live main, and record whether the user approved refresh or accepted snapshot-bound evidence. -->

Implementation issues must be fully self-contained. Do not rely on external
repository access or links; this strictly prohibits cross-repository references.
Include complete, verbatim code snippets and exact configuration examples inline
whenever adopting a pattern from elsewhere.

## Confirmed decisions

<!-- Record decisions made during clarification, including rejected alternatives when material. -->

## Scope and non-goals

<!-- Define the smallest coherent scope and explicit exclusions. -->

## Existing architecture, reuse, and affected seams

<!-- Identify existing owners, types, helpers, packages, APIs, imports, test seams, deployment, and consumers. State what will be reused, what obsolete duplication/dead code is removed in scope, and justify any new abstraction or dependency. -->

## Contract symbols and SDK versions

<!-- For every consumed external or cross-repository contract, declare the exact DTO/schema symbol names, package and version tag, and import path that implementation must use. Include runtime schema/validator symbols when applicable; do not leave SDK discovery to tarball unpacking or broad type dumps. -->

- Contract package and version: `<!-- @package/name@x.y.z -->`
- DTO/schema symbols: `<!-- Exact exported symbol names -->`
- Import paths: `<!-- Exact package/module import paths -->`

## Proposed behavior, data flow, and performance

<!-- Describe the end-to-end flow and component responsibilities without speculative refactoring. For performance-sensitive work, state expected scale/hot paths, resource risks, and measurable regression evidence. -->

## Requirement-to-delivery traceability

| Requirement | Implementation task and seam | RED evidence | GREEN / final verification | Documentation |
|---|---|---|---|---|
| <!-- REQ-ID: precise outcome --> | <!-- Exact file/seam and ordered task --> | <!-- Focused test, command, and expected missing-behavior failure --> | <!-- Assertion, broader command, and required evidence --> | <!-- Exact file and content change, or N/A with reason --> |

## Contracts, validation, persistence, and migrations

<!-- Import or compose published contract-repository types, runtime schemas/validators, constants, and generated clients instead of recreating local DTOs/schemas. Static types do not replace runtime validation. Identify any missing upstream artifact or justified local adapter, including mapping tests. Define trust-boundary validation, ORM usage, and migration/compatibility needs. -->

## Edge cases, failure handling, concurrency, idempotency, rollback, and security

<!-- Keep only applicable normal/empty/boundary/invalid, production-failure, and trust-boundary requirements. -->

## Observability

<!-- For production behavior, prefer the established structured logger and OpenTelemetry integration instead of creating a parallel stack. Define useful logs/spans and low-cardinality rate/error/latency/saturation metrics; exclude secrets, sensitive payloads, noisy per-item telemetry, and high-cardinality labels. Remove this section when not applicable. -->

## Required tests

<!-- Name exact files/seams, setup, commands, scenarios, and assertions. Cover happy plus relevant boundary/invalid/failure/regression paths and real boundaries that mocks cannot prove. -->

## TDD execution order

<!-- List dependency-ordered RED → GREEN → REFACTOR tasks. RED must capture the expected failure caused by missing behavior; GREEN is the minimum implementation plus targeted and broader checks; refactor only while green. -->

## Documentation, local wiki, deployment, and architecture

<!-- Make documentation explicit implementation tasks. Name exact files, required content, requirement mapping, and documentation validation. Update the owning existing spec and affected ADR/wiki/API/operational/configuration/example docs in the same change. Create a new spec only for a genuinely new requirement. -->

## Delivery mode and Spec Kit gate

<!-- State exactly one mode. Existing artifacts: link the approved spec.md, plan.md, tasks.md, reviewed PR, and remote ref; start at speckit-implement. Pre-approved cloud execution: Spec Kit artifacts are planned and approved locally in advance; cloud agent performs bounded implementation only. No-Spec-Kit maintenance: cite the repository policy that permits the behavior-preserving change, use acceptance criteria as the execution contract, do not reference nonexistent artifacts or run Spec Kit commands, and stop for reclassification if scope grows materially. NEVER task autonomous cloud agents with end-to-end specification or interactive human-approval ceremonies. In Spec Kit modes, stop/report material artifact mismatches instead of silently rewriting the contract. -->

## Cross-repository dependencies and ownership

<!-- Name the owning repository, contract, sequencing, and work that blocks completion. -->

## Acceptance criteria

- [ ] <!-- Dependency-ordered, independently verifiable outcome. -->

## Definition of Done

- [ ] No test or validation checkbox may be marked complete unless its required command passed on the final revision; record exact command/output evidence and leave skipped, blocked, remote-only, or unexecuted checks incomplete.
- [ ] Terminal, non-retriable failures stop dependent work immediately, are reported with sanitized evidence and the required recovery action, and remain incomplete; retries are bounded and reserved for failures evidenced as transient.
- [ ] In case of terminal failure, circuit breaker, or threshold breach, current progress is committed as WIP and pushed to the remote branch (`wip: checkpoint before halt`) without discarding code or resetting working trees (`git reset --hard` forbidden); PR remains as Draft with a clear handover report.
- [ ] Handwritten code changes remain within the ≤300 line diff limit across 1–3 files (excluding generated assets and lockfiles), verified by external CI guardrails.
- [ ] The complete documented local test/validation suite passes on the final revision, including required integration/E2E setup and commands: `<!-- exact commands and results -->`.
- [ ] Every CI-equivalent check available locally passes, and all required PR status checks are green on the final revision: `<!-- enumerate checks -->`.
- [ ] Credential-gated, hosted-service, protected-environment, and other remote-only checks remain explicitly unchecked until their actual environment reports success.
- [ ] Relevant happy, boundary, invalid-input, failure, and regression scenarios pass at the appropriate unit/contract/integration/E2E seams; real boundaries are not replaced by mock-only evidence.
- [ ] Consumed contracts use the contracts repository's published types and runtime artifacts; any repository-specific adapter has explicit mapping and conformance tests: `<!-- imports/artifacts/tests, or N/A -->`.
- [ ] Every in-scope `spec.md` requirement maps to implementation, tests, and current documentation; no requirement has missing or partial coverage: `<!-- paths, or N/A when Spec Kit does not apply -->`.
- [ ] Performance-sensitive changes include passing benchmark or before/after evidence against the stated scale or budget: `<!-- exact command/result, or N/A with reason -->`.
- [ ] Existing specs, ADRs, API/operational docs, wiki, examples, and configuration guidance are current for the delivered behavior: `<!-- paths, or N/A with reason -->`.
- [ ] When Spec Kit applies, `tasks.md` reflects the delivered state honestly; blocked, deferred, human-only, and unverified requirements remain unchecked and prevent completion where required: `<!-- path, or N/A when Spec Kit does not apply -->`.
- [ ] The final branch contains the Jira key (when applicable) for human/local branches, or preserves the native copilot/* branch prefix for GitHub Copilot cloud agent tasks; every authored commit contains the key when applicable; and the PR title and description link the Jira URL when present.
- [ ] The required independent implementation review checks every confirmed requirement and acceptance criterion against the final diff and fresh evidence, then returns the repository's accepted verdict with no unresolved blocking findings. A REJECT includes prioritized, specific minimum-change remediation and is reviewed again after fixes.

## Incomplete follow-ups

- [ ] <!-- External, deferred, human-only, blocked, or unverified work that must not be claimed complete. -->
