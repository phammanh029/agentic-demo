---
name: create-implementation-issue
description: Use when a user wants one local, evidence-backed issue draft for cloud or local delivery of a feature, bug, migration, or architecture proposal. Reuse existing Spec Kit artifacts, delegate their creation as the first cloud phase when required, or record why repository policy permits no-Spec-Kit maintenance. Do not use for remote issue publication or conversion of an existing tasks.md.
---

# Draft an Implementation Issue

Draft one evidence-backed issue document, select the applicable Spec Kit or no-Spec-Kit handoff mode, save the issue locally, and stop. This skill does not implement the change, publish the issue, or create a remote GitHub issue.

If the user wants issues created from an existing `tasks.md`, use
`speckit-taskstoissues` instead. That workflow publishes task issues; this skill
creates one pre-implementation local issue.

## Boundaries

During this workflow, write the final issue beneath `.tmp/github-issues/`. When
the user chooses local planning before cloud handoff, create or update only the
relevant Spec Kit artifacts under `specs/<feature>/`. When the user delegates
planning to the cloud agent, leave those artifacts for the cloud phase and make
that phase explicit in the issue. Keep sibling repositories read-only. Do not
edit source, implementation tests, documentation, deployment files, or runtime
configuration.
Do not stage, commit, push, publish, create a GitHub issue, or mutate another
remote system.

Local output means ignored and unstaged. Before research, capture the current
and inspected sibling repositories' status, full tracked and staged diffs, and
hashes of pre-existing untracked files. Never run `git add`. Before reporting,
compare those snapshots, excluding only the expected ignored issue. Any other
difference is a violation: report it and stop. Unstage only a generated issue
that was absent from the baseline and newly staged by this workflow; otherwise
never restore, unstage, or disturb user state.

After the issue and any locally planned Spec Kit artifacts are saved and
reported, stop. In cloud-bootstrap mode, report that artifact creation is part
of the delegated phase rather than creating the files locally. Do not implement
the change, execute implementation tasks, or publish the issue.

## Mandatory Spec Kit gate

Spec Kit is required for every substantial issue produced by this skill, but the
artifacts do not have to exist before the issue is drafted. Behavior-preserving
maintenance may skip Spec Kit only when repository policy explicitly permits it.
Choose and record one of these handoff modes:

- **Existing-artifacts mode:** reuse aligned `spec.md`, `plan.md`, and `tasks.md`.
  They must be committed and pushed, or explicitly included with `/delegate`, so
  the cloud agent can access them.
- **Cloud-bootstrap mode:** the issue delegates `specify → clarify → plan → tasks
  → analyze` to the cloud agent as its first phase. The agent commits the artifacts
  to its PR branch, runs the configured read-only reviews, and pauses for the
  required human approval before implementation. After approval, the same cloud
  session continues with `speckit-implement`; it must reuse rather than regenerate
  the artifacts it just created.
- **No-Spec-Kit maintenance mode:** the issue cites the repository rule that
  permits the behavior-preserving change to proceed without `spec.md`, `plan.md`,
  or `tasks.md`. Its dependency-ordered acceptance criteria are the execution
  contract, and the normal verification, independent-review, and human-merge gates
  still apply. If scope grows materially, stop and enter the Spec Kit lifecycle.

When Spec Kit applies and no aligned artifacts exist, default to
**cloud-bootstrap mode** so one cloud session owns planning through verified
implementation. Use local planning only when the user explicitly requests it or
cloud delegation is unavailable.

When Spec Kit applies, use an artifact-first lifecycle: establish or update the
aligned `spec.md`, `plan.md`, and `tasks.md` before implementation. These artifacts
are the implementation contract and must be internally consistent before work
starts. In no-Spec-Kit maintenance mode, do not create or reference ceremonial
artifacts.
If a material decision is unresolved, explain the evidence, options, trade-offs,
and recommendation, then ask for the missing input. If requirements and evidence
are clear, do not pause for ceremonial approval; proceed through the implementation
workflow after this drafting boundary.

Use the configured high-reasoning planning role for the research, requirements
shaping, task decomposition, and drafting performed by this skill. In Codex this
is the `planner` role; on another supported surface, use its matching pinned
planning profile. The primary agent remains responsible for checking the draft
against repository evidence. Do not merely mention the role in the issue: route
the drafting work through it and record the runtime evidence for the role used.
If the required high-reasoning role is unavailable, report the limitation and ask
the user before continuing with a weaker profile; never claim that a role or model
ran without runtime evidence.

Write tasks with enough detail that a future implementer can act without guessing.
Use lighter-weight models such as Luna for routine implementation work when the
change is bounded and low risk.
Escalate back to Sol for implementation when the work touches authentication,
authorization, tenant isolation, secrets, migrations, infrastructure,
production risk, or any case where Luna cannot safely resolve the task.
If a downstream implementation profile is unavailable, use the strongest compatible
available profile and record that fallback; never claim a profile was used without
runtime evidence.

1. Inspect `specs/` for an active feature whose scope owns the requirement and
   determine whether repository policy requires Spec Kit. If policy permits a
   localized behavior-preserving change to skip it, use no-Spec-Kit maintenance
   mode, cite that rule in the issue, and skip the artifact-specific steps below.
2. When Spec Kit applies and aligned artifacts already exist, use
   existing-artifacts mode. If the
   requirement belongs to an existing feature, update that feature's
   `spec.md` and any directly dependent Spec Kit artifacts (`plan.md`,
   `research.md`, `data-model.md`, `contracts/`, `quickstart.md`, or
   `tasks.md`) only when the requirement changes them. Preserve existing
   decisions and do not create a parallel feature spec.
3. When Spec Kit applies, if aligned artifacts do not exist and the user wants
   end-to-end cloud delivery, use cloud-bootstrap mode. The issue must name any existing owning
   feature directory or require the cloud agent to create exactly one through
   `speckit-specify`; it must not create a parallel feature for existing scope.
   If the user instead wants local planning, create the artifacts before drafting.
4. Keep the Spec Kit change minimal: change only the requirements, decisions,
   contracts, tasks, and verification boundaries required by the user's
   request. Do not add speculative architecture, refactors, or unrelated
   cleanup.
5. In existing-artifacts mode, the issue must cite the resulting Spec Kit
   artifacts and remote ref. In cloud-bootstrap mode, it must name the expected
   feature directory and artifact outputs, require them to be committed to the
   cloud PR branch, and make implementation wait for their reviews and human
   approval. In no-Spec-Kit maintenance mode, it must record the policy basis and
   use the issue acceptance criteria without naming nonexistent artifacts. Ask for
   clarification only when a material unresolved choice,
   high/critical risk, or external blocker could change architecture, contracts,
   security, operations, ownership, or acceptance criteria.

6. The issue must define the downstream delivery chain explicitly. In
   existing-artifacts mode, the cloud agent starts at `speckit-implement`. In
   cloud-bootstrap mode, it creates and commits the artifacts, pauses at the
   planning review/human gate, and resumes the same session at `speckit-implement`
   after approval. In no-Spec-Kit maintenance mode, it implements directly against
   the issue acceptance criteria and does not run Spec Kit commands. In every mode,
   work is marked complete only as it is actually verified → implementation
   verification → the appropriate independent review skill evaluates the
   implementation. If implementation exposes a material
   artifact gap or contradiction, it stops and reports the mismatch for
   planner/human resolution instead of silently rewriting the approved contract.
   The implementation must not be declared complete unless the review returns the
   repository's accepted verdict (`ACCEPT`).

7. The issue must record how the cloud agent will persist and access the artifacts.
   In existing-artifacts mode, link the reviewed Spec Kit PR and name its remote
   branch or immutable commit; a local path by itself is not a valid cloud handoff.
   `/delegate` may carry explicitly selected local changes, but the issue must
   record that exception and the resulting PR must include the artifacts. In
   cloud-bootstrap mode, require the agent's PR branch to contain the artifacts
   before the planning gate and retain them when implementation resumes.

8. The independent implementation review must check the delivered diff and fresh
   verification against every confirmed requirement, acceptance criterion, and
   applicable Spec Kit artifact. If it returns `REJECT`, or identifies Critical or
   Important findings, the implementation remains incomplete. Each rejection must
   cite the unmet requirement and evidence, explain the impact, and recommend the
   specific minimum-change remediation. The owner must address the findings, rerun
   the relevant verification, and obtain a new `ACCEPT` verdict before closing the
   work or claiming completion.

## Research before drafting

1. Before relying on the current or any sibling repository, record its current
   branch, HEAD, worktree status, local `origin/main`, and—when remote access is
   available—the live `refs/heads/main` SHA from `git ls-remote origin` without
   mutating the checkout. Warn the user when a repository is not on `main`, when
   its HEAD differs from live `main`, when local `origin/main` is stale, or when
   remote freshness cannot be verified. Group the affected repositories into one
   concise question and ask whether to refresh from `main` or continue using the
   identified snapshot.
2. Never blindly pull into a dirty worktree or a non-`main` branch. After explicit
   approval, use only a clean fast-forward update (`git pull --ff-only origin main`)
   when the checkout is clean and currently on `main`. Otherwise stop and ask for
   a safe target, such as a separate clean checkout/worktree; do not merge or
   rebase `main` into the user's feature branch. If the user chooses not to refresh,
   record the branch/SHA and stale-state warning in the issue evidence and treat
   conclusions from that repository as snapshot-bound.
3. Read the nearest `AGENTS.md`, repository validation commands, relevant active
   Spec Kit artifacts, ADRs, source seams, tests, deployment configuration, and
   local wiki.
4. Inspect the current worktree without changing it. Preserve unrelated and
   pre-existing changes.
5. Trace relevant contracts and ownership into sibling repositories. Read their
   instructions first and inspect them read-only.
6. Use CodeGraph first for structural discovery when its index is available:
   `search_graph` for definitions, `trace_path` for callers and callees, and
   `get_code_snippet` for exact source context. Before relying on those paths,
   run `check_index_coverage` for every evidence file. Fall back to direct source
   reads or literal search for uncovered ranges, stale or unavailable indexes,
   paths, configuration, documentation, tests, and exact strings. Record the
   graph project/generation, coverage limitations, and fallback evidence so the
   implementer does not repeat settled discovery.
7. Classify evidence as verified fact, inference, unknown, or recommendation.
   Never invent APIs, fields, commands, behavior, citations, or test results.

8. For production bugs and deployment failures, diagnose the root cause before drafting a
   workaround. Read the complete error, reproduce or minimize it at the narrowest available
   seam, trace the failing value through configuration and module boundaries, and compare the
   requested behavior with authoritative platform capability documentation. Rank multiple
   falsifiable hypotheses before selecting a fix. Do not frame disabling, bypassing, weakening,
   or deleting the failing capability as the solution unless evidence shows the intended behavior
   is genuinely unsupported and the user has approved that trade-off.

9. Preserve intended reliability, security, and availability behavior whenever a supported
   compatibility mode exists. When an external platform blocks one mode but supports a safer
   fallback, make that fallback the primary proposal and keep capability removal as an explicit,
   human-approved contingency. Record the evidence, trade-offs, rollback path, and verification
   gate in the issue.

## Clarify material decisions

Ask one question per turn only when needed. Include a recommendation and concise trade-off when
useful. Continue while an unknown materially affects architecture, contracts, security, persistence,
testing, operations, or repository ownership. If those decisions are already clear from the user
request and repository evidence, proceed without asking for confirmation. Record non-blocking
unknowns as incomplete follow-ups rather than guessing.

The Jira ticket key is standard delivery identity. Extract it from the supplied
Jira URL or issue context when provided. Validate the key as an uppercase project
key plus number (for example, `SHOP-1234`) and record the canonical Jira URL. If
the user explicitly skips the Jira key, asks for a GitHub branch without Jira, or
Jira tracking is not requested, record `Jira: none` and use standard GitHub naming
without requiring a Jira ticket key. Do not invent a ticket key.

When confirmation is genuinely required, do not merely block or say that information is missing.
Explain:

1. What is known and what remains uncertain, with the repository or authoritative evidence.
2. Why the decision matters and what behavior, risk, ownership, or delivery date it changes.
3. The concrete options, including the trade-offs and consequences of each.
4. The recommended option and why it best preserves the requested outcome.
5. One focused question asking the user to choose or supply the missing decision.

If a safe, reversible default exists, state it and continue while recording the decision as an
assumption. Only stop drafting when proceeding would create a material risk of contradicting the
user's intent or the repository's governance.

For an error report, do not treat the first operationally convenient change as a confirmed
decision. The issue must distinguish root cause from containment, evaluate supported alternatives
(including platform/provider capability, configuration compatibility, and region or capacity
constraints), and state why the selected approach preserves or changes the intended behavior. A
proposed feature disablement is a last-resort contingency, not the default acceptance criterion.

Challenge unnecessary scope and enforce bounded delivery size. Include only
changes strictly required by the confirmed outcome. Never bundle a broad
refactor or multi-domain initiative into a single issue. When an initiative
touches multiple distinct architectural layers (such as Spec Kit planning,
Terraform infrastructure, GitOps manifests, contract validators, and runbooks),
decompose the work into staged, sequential phase issues with single-domain
write sets instead of silently expanding a monolithic issue. Follow existing
architecture and naming, and reuse existing types, schemas, helpers,
dependencies, and test infrastructure. Prefer the repository ORM; use raw SQL
only for a demonstrated performance or database-specific requirement. Treat
imports and test seams as intentional when tests depend on them; preserve them
unless the approved requirements explicitly replace them.

Require the eventual implementation to make the smallest coherent change. Add
or update tests whenever the requirement changes observable behavior, a
contract, security boundary, infrastructure behavior, or a validation seam.
Name the relevant test files/seams and concrete assertions in the issue. If no
test is relevant, record the reason explicitly; never omit tests merely to keep
the issue short.

## Issue quality contract

The issue is an executable delivery contract, not a broad design suggestion.
Keep each requirement precise, goal-oriented, evidence-backed, and independently
verifiable.

Assume the implementation issue may be executed by a low-effort, token-efficient
model. Spend precision while drafting to save tokens during execution. Each task
must be self-contained and state the goal, exact seam, required evidence, ordered
action, expected result, verification command, and stop condition. Prefer short,
imperative instructions, concrete examples, and explicit requirement IDs over
repeated background prose. Do not require the implementer to infer omitted
requirements, rediscover already verified facts, or choose among unresolved
material alternatives.

- **Self-contained specifications & concrete examples**: Implementation issues
  must be fully self-contained. Never rely on external repository access (e.g.,
  "do like repo X" or external repo URLs); this strictly prohibits
  cross-repository references. Whenever adopting a pattern or configuration from
  another repository, always provide complete, verbatim code snippets and exact
  configuration examples directly in the issue body so agents running in
  isolated single-repository worktrees have full context.
- **Bounded issue scope & token budget**: Keep issue prompt bodies strictly
  bounded (target < 200 lines, maximum 300 lines). Never dump whole spec files,
  large test logs, or massive background narratives into the issue description;
  cite repository-relative paths with exact line numbers instead.
- **Pre-implementation readiness gate & DoD**: Never write code on incomplete information.
  Require an explicit Definition of Done, exact non-interactive verification commands
  (`vitest run`, `node --test --test-timeout=10000`, `pnpm typecheck`, `pnpm lint`),
  and a verified seam. If requirements, contracts, or edge cases are ambiguous, STOP and ask.
- **Pre-implementation AIC budget & task splitting**: Estimate Agent-Incurred Cost (AIC) before
  drafting. If a task requires >300 lines, >15 turns, or >40k tokens (High AIC), do not draft
  a monolithic issue: decompose into staged, sequential phase issues with single-domain write sets.
- **Preservative fail-fast & checkpointing**: Fail-fast must preserve progress and halt token
  burn—never destructively reset (`git reset --hard`) or discard working trees. When encountering
  a terminal failure, diff limit (>300 lines), or turn ceiling, stage and commit working changes
  (`wip: checkpoint before halt`), push to the remote task branch, mark the PR as Draft with a clear
  handover diagnosis, and halt autonomous execution.
- **Decomposition of multi-domain features**: Never combine multiple architectural
  domains (e.g. Spec Kit planning + Terraform infrastructure + GitOps manifests +
  validator scripts + runbooks) into a single monolithic issue. Decompose broad
  initiatives into staged, sequential phase issues with single-domain write sets so
  downstream agents complete work without multi-turn token explosion or context exhaustion.

| Concern | Required issue content |
|---|---|
| Goal and scope | One observable outcome, current behavior, explicit non-goals, assumptions, blockers, and stop conditions. |
| Ordered implementation | Exact files or discovered seams, repository evidence, existing code/types/helpers to reuse, dependency-ordered edits, and the smallest coherent change. |
| TDD | For each observable behavior, order work as **RED → GREEN → REFACTOR**: write the focused test, run it and capture the expected failure caused by the missing behavior, complete the Minimal implementation task, rerun the targeted and broader required checks, then Refactor only while the tests remain green. A setup error, compilation typo, or test that passes immediately is not RED evidence. |
| Documentation | Documentation is an implementation deliverable. Name the exact documentation files and the documentation requirement each fulfills; if evidence cannot identify a path, add an explicit discovery task and stop condition. Include documentation validation and keep the task incomplete until the docs, examples, configuration, API/operational guidance, and owning Spec Kit artifacts affected by the change are current. |
| Performance and scale | For a material hot path, state a measurable scale or performance target, bounded resource/concurrency behavior, and a reproducible before/after command. Otherwise record why a benchmark is not applicable. |
| Extensibility | Name an approved variation or extension point only when requirements or repository evidence establish one. Reuse an existing pattern when it fits. Do not require a design pattern merely for pattern's sake; straightforward, testable code is preferred to a speculative abstraction or generic framework. |
| Terminal failures | Classify deterministic failures such as authentication or authorization denial, missing required credentials, invalid required configuration, unsupported capability, and contract contradiction as terminal unless repository evidence explicitly defines a recovery path. Do not retry a terminal failure or disguise it with a fallback; stop dependent work, preserve evidence without secrets, keep affected tasks incomplete, and state the required human or upstream action. Define a bounded retry count and backoff only for failures proven transient. |
| Preservative fail-fast | In case of terminal failure, threshold breach, or circuit breaker, commit working progress (`wip: checkpoint before halt`), push to the remote branch, keep PR as Draft with a structured handover report, and halt token burn; never run `git reset --hard` or discard working trees. |
| PR guardrails | Keep handwritten code changes strictly within <= 300 lines across 1-3 files (excluding generated files and lockfiles); enforce via external CI check. |
| Honest verification | A test or validation item is complete only after its required command runs successfully against the final revision. Never mark a test complete from an earlier revision, partial suite, expected result, or unexecuted CI plan. Record the exact command and outcome; keep blocked, skipped, remote-only, and unexecuted checks explicitly incomplete. |

Every confirmed requirement must map to at least one implementation task and
verification method, plus documentation when the behavior, contract, operation,
configuration, decision, or workflow is affected. Do not hide ambiguity behind
phrases such as "as needed", "best practice", "make scalable", "handle errors",
or "add tests". Replace them with the applicable boundary, expected behavior,
measurable constraint, exact seam, assertion, and completion evidence.

## Compose the issue

When the implementation is `APPROVED`, the issue and review evidence must still record residual risks, limitations, and remote-only or environment-dependent gaps for human review.

Read `.agents/skills/create-implementation-issue/assets/github-issue-template.md`. Use only sections relevant to the work,
and remove unused headings and all template comments.
For a concrete example of the required task, traceability, TDD, documentation,
and verdict shape, read [references/example.md](references/example.md). Adapt its
structure to repository evidence; do not copy its domain facts or invented paths.

- Cite evidence with repository-relative paths and line numbers. Prefix sibling
  evidence with its repository name.
- Include a **Delivery identity** section with the Jira key and URL (or `Jira: none`
  when skipped) plus exact branch, commit, PR-title, and PR-description requirements.
  Follow a documented target-repository convention when one exists; otherwise use these defaults:
  branch `<type>/<JIRA-KEY>-<short-slug>` (or `<type>/<short-slug>` when Jira is skipped),
  commit `<type>(<optional-scope>): <JIRA-KEY> <summary>` (or `<type>(<optional-scope>): <summary>` when Jira is skipped),
  and PR title `[<JIRA-KEY>] <concise outcome>` (or `<concise outcome>` when Jira is skipped).
  When a Jira key is present, every authored implementation commit and the final squash/merge commit
  title should contain the Jira key, and the PR description should link the Jira URL.
- For human and local agent branches, the branch name should contain the Jira key when supplied
  (e.g., `feat/SHOP-1234-checkout-timeout` or `feat/checkout-timeout`). For GitHub Copilot cloud agent tasks,
  do NOT instruct the agent to rename the branch away from `copilot/*`: Copilot
  cloud agent runner credentials strictly permit pushing only to `copilot/*`
  branches, and renaming triggers a fatal HTTP 403 on push. When Jira is used, the key must still
  be included in the issue title, PR title, and commit messages.
- Make cross-repository ownership and sequencing explicit.
- Include an **Implementation approach and quality** section. Require the
  implementer to follow the repository's decision ladder and identify what existing
  code, types, helpers, test infrastructure, and dependencies will be reused. Require
  a minimal, cohesive implementation that removes duplication or dead code made
  obsolete by the change without unrelated cleanup or premature abstraction. When
  the target repository consumes a contract from
  the contracts repository, require its published types, runtime schemas/validators,
  constants, and generated clients to be imported or composed instead of recreating
  local DTOs or validation schemas. Static types do not replace runtime validation;
  use the canonical runtime parser when available. If an artifact is missing,
  update the owning contract first or record the cross-repository dependency. Allow
  a local adapter only for a real repository-specific model, with explicit mapping
  and tests. If a new dependency is justified, prefer a mature,
  maintained open-source library after checking license, security, maintenance,
  compatibility, bundle/runtime impact, and operational cost; do not add a
  dependency for trivial logic or rebuild a suitable library.
- Require the issue to enumerate only applicable normal, empty, boundary, invalid,
  partial-failure, timeout, retry, concurrency, idempotency, rollback, compatibility,
  security, and operability cases. For performance-sensitive work, state expected
  scale and hot paths, prevent N+1 access, redundant I/O or serialization, unbounded
  queries/concurrency/memory, and missing pagination/backpressure, and name the
  benchmark or before/after measurement that will detect a material regression.
  Do not demand speculative micro-optimization.
- Require production changes to prefer the repository's established structured
  logger and OpenTelemetry integration instead of creating a parallel stack.
  Specify the context-rich logs and spans needed to debug behavior and performance,
  plus low-cardinality rate, error, latency, and
  saturation metrics where relevant. Exclude secrets, sensitive payloads, noisy
  per-item telemetry, and high-cardinality labels.
- Make tests executable requirements, not prose placeholders. Name exact test files
  or seams, scenarios, assertions, local setup, and commands. Cover the happy path
  plus relevant boundary, invalid-input, failure, retry/concurrency/idempotency, and
  regression cases. Require contract, integration, or end-to-end tests at real
  persistence, HTTP, messaging, or service boundaries where mocks cannot prove the
  behavior. Require the issue to preserve the RED failure output and final GREEN
  output as implementation evidence. For a non-behavioral change, record why no
  test addition is relevant.
- Keep documentation in scope. Require the owning existing spec, `tasks.md`, ADRs,
  API/operational docs, wiki, examples, and configuration guidance to be updated in
  the same change whenever requirements, behavior, contracts, decisions, or
  workflows change. Create a new spec only for a genuinely new requirement; do not
  require Spec Kit artifacts for behavior-preserving cleanup when repository policy
  does not require them. Represent each applicable documentation update as an
  implementation task with its exact target, content change, validation, and
  requirement mapping; never leave documentation as a Definition-of-Done reminder
  detached from the implementation plan.
- Include a **Definition of Done** with exact commands and evidence. It must require:
  1. the repository's complete documented local test/validation suite, including
     required integration or end-to-end tests, to pass on the final revision;
  2. every CI-equivalent check available locally and every required PR status check
     to pass; credential-gated, hosted-service, protected-environment, and other
     remote-only checks remain explicitly unchecked until the actual environment
     passes;
  3. every in-scope `spec.md` requirement to map to implementation, tests, and
     current documentation, with missing, partial, deferred, or human-only work
     visible rather than silently omitted;
  4. performance evidence when the change can materially affect a hot path,
     resource usage, latency, throughput, or build/runtime size;
  5. delivery identity and the required independent implementation review to pass.
- The implementation is incomplete until every applicable final-revision gate passes:
  Docker image build, complete test suite, formatting/linting, and local integration
  tests when the repository provides them. Record the exact command and result for
  each gate; a failed, skipped, or unverified gate blocks completion. The final PR
  must contain file changes unless zero changes are genuinely reasonable, in which
  case the PR must explain why. The implementation review must return one consistent
  binary verdict, `APPROVED` or `REJECTED`; `REJECTED` must list the failed gate or
  finding and provide a concrete minimum-change suggestion before another review.
- In existing-artifacts mode, cite `spec.md` and dependent artifacts and record
  their reviewed PR plus remote branch or immutable commit. Do not treat local-only
  paths as available to a cloud agent. In cloud-bootstrap mode, name the expected
  artifact paths and require the cloud PR to persist them before implementation.
- Include a delivery-mode section in every issue. When repository policy requires
  Spec Kit, include the applicable Spec Kit delivery chain. In no-Spec-Kit
  maintenance mode, cite the policy basis, state that acceptance criteria are the
  execution contract, prohibit nonexistent artifact references, and require a stop
  and reclassification if scope grows materially. Do not create ceremonial
  artifacts. Mention a confirmation gate only when a material ambiguity,
  high/critical risk, or external blocker exists. The skill may create or update the
  minimal required artifacts but must not implement their tasks.
- Include an explicit implementation/review completion gate. For Spec Kit work,
  implementation uses `speckit-implement` against the approved `spec.md`, `plan.md`,
  and `tasks.md` without regenerating them and stops on material artifact mismatch.
  For work that legitimately skips Spec Kit, require the same fresh verification and
  accepted review verdict without referencing nonexistent artifacts.
- Acceptance criteria must include the review verdict and must leave review, unresolved findings,
  skipped verification, and human-only deployment evidence visibly incomplete.
- When Spec Kit applies and `tasks.md` exists, state that it is the live progress
  ledger: update it as tasks are genuinely completed, leave blocked, skipped,
  human-only, and unverified tasks unchecked, and reconcile remaining work before
  review. Do not reference `tasks.md` for work that legitimately skips Spec Kit.
- Keep acceptance criteria dependency-ordered and independently verifiable.
- Leave external, human-only, blocked, and unverified work visibly incomplete.

Review the completed issue against all confirmed decisions and cited evidence
before writing it.

Before writing, perform a final consistency check across the issue and all existing
`spec.md`, `plan.md`, and `tasks.md` artifacts: the proposed behavior, tests,
operational safeguards, and completion gate must agree. In cloud-bootstrap mode,
require the same consistency check from the cloud agent before it requests planning approval.
If the issue proposes a workaround that weakens the specified reliability or security behavior,
stop and either replace it with an evidence-backed supported approach or record the explicit human
decision that authorizes the trade-off.

## Requested issue verdict

Only when the user explicitly asks for a verdict on the issue, route a read-only
review of the completed draft through the configured independent high-reasoning reviewer
(`reviewer` in Codex or the matching pinned review profile). The drafter
must not review its own output in place of that independent pass. If the required
high-reasoning role is unavailable, report the limitation and ask before using a
weaker profile; never claim that a role or model ran without runtime evidence.

Review every confirmed requirement against the user request, owning `spec.md` and
dependent artifacts when present, repository policy, cited evidence, proposed
implementation tasks, RED/GREEN test evidence requirements, documentation work,
acceptance criteria, and Definition of Done. Return exactly one leading verdict:

- **`ACCEPT`** — every requirement is unambiguous and maps to sufficient
  implementation, tests, documentation, verification, and delivery evidence, with
  no unresolved blocking finding. State residual risks or remote-only gaps.
- **`REJECT`** — for every blocking finding, give its severity, unmet or ambiguous
  requirement, exact issue/evidence location, impact, specific minimum-change
  remediation, and recommended issue edit. Finish with the recommended order of
  fixes and require the owner to run a fresh review after remediation. Do not edit
  the issue unless the user separately asks for fixes.

A draft with any unresolved required input, placeholder, unverified material
evidence, contradictory requirement, or incomplete acceptance threshold cannot receive `ACCEPT`;
return `REJECT` and identify the minimum path to readiness.

## Write safely

Derive the slug from a human-readable feature name by lowercasing it, replacing
runs of non-alphanumeric characters with one hyphen, and trimming surrounding
hyphens. The result must match `[a-z0-9]+(?:-[a-z0-9]+)*`. If the user instead
supplies an explicit output slug or path, reject absolute paths, separators,
`..`, or an invalid slug; do not reinterpret path-like input as another output
location.

The only valid target is `.tmp/github-issues/<slug>.md` in the current
repository. Before writing:

1. Inspect each existing ancestor without following links. Reject the operation
   if `.tmp`, `.tmp/github-issues`, or the target is a symbolic link.
2. Create only the fixed `.tmp/github-issues/` chain when it is absent.
3. Resolve the repository and created output directory, verify the output is the
   repository's `.tmp/github-issues/`, and construct the target as its direct
   child. Reject any containment mismatch.
4. If the target exists, ask before replacing it. A declined replacement leaves
   the file unchanged.

Write the issue with a structured editing tool. Re-read it after writing, report
its repository-relative path plus unresolved dependencies, and stop.
